document.addEventListener('DOMContentLoaded', function() {
    console.log('Carrito de compras cargado');
});
